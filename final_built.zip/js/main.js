// var body = $('body');
//     body.scrollspy({
//         'target': '#navbar-example2',
//         'offset': 100 //this must match the window.scrollY below or you'll have a bad time mmkay
// });

// $(window).on("hashchange", function () {
//         window.scrollTo(window.scrollX, window.scrollY - 100);
// });
var scrollSpy = new bootstrap.ScrollSpy(document.body, {
    target: '#navbar-example2'
  })